function execute() {
    return Response.success([
        { title: "Huyền Huyễn", input: "https://doctruyenchufull.xyz/huyen-huyen", script: "gen.js" },
        { title: "Tiên Hiệp", input: "https://doctruyenchufull.xyz/tien-hiep", script: "gen.js" },
        { title: "Ngôn Tình", input: "https://doctruyenchufull.xyz/ngon-tinh", script: "gen.js" },
        { title: "Đô Thị", input: "https://doctruyenchufull.xyz/do-thi", script: "gen.js" },
        { title: "Xuyên Không", input: "https://doctruyenchufull.xyz/xuyen-khong", script: "gen.js" },
        { title: "Trọng Sinh", input: "https://doctruyenchufull.xyz/trong-sinh", script: "gen.js" },
        { title: "Tu Chân", input: "https://doctruyenchufull.xyz/tu-chan", script: "gen.js" },
        { title: "Kiếm Hiệp", input: "https://doctruyenchufull.xyz/kiem-hiep", script: "gen.js" },
        { title: "Hệ Thống", input: "https://doctruyenchufull.xyz/he-thong", script: "gen.js" },
        { title: "Cung Đấu", input: "https://doctruyenchufull.xyz/cung-dau", script: "gen.js" },
        { title: "Đam Mỹ", input: "https://doctruyenchufull.xyz/dam-my", script: "gen.js" },
    ]);
}