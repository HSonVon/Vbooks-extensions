let BASE_URL = 'https://doctruyenchufull.xyz';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}