function execute() {
    return Response.success([
        { title: "Huyền Huyễn", input: "https://doctruyenchufull.online/huyen-huyen", script: "gen.js" },
        { title: "Tiên Hiệp", input: "https://doctruyenchufull.online/tien-hiep", script: "gen.js" },
        { title: "Ngôn Tình", input: "https://doctruyenchufull.online/ngon-tinh", script: "gen.js" },
        { title: "Đô Thị", input: "https://doctruyenchufull.online/do-thi", script: "gen.js" },
        { title: "Xuyên Không", input: "https://doctruyenchufull.online/xuyen-khong", script: "gen.js" },
        { title: "Trọng Sinh", input: "https://doctruyenchufull.online/trong-sinh", script: "gen.js" },
        { title: "Tu Chân", input: "https://doctruyenchufull.online/tu-chan", script: "gen.js" },
        { title: "Kiếm Hiệp", input: "https://doctruyenchufull.online/kiem-hiep", script: "gen.js" },
        { title: "Hệ Thống", input: "https://doctruyenchufull.online/he-thong", script: "gen.js" },
        { title: "Cung Đấu", input: "https://doctruyenchufull.online/cung-dau", script: "gen.js" },
        { title: "Đam Mỹ", input: "https://doctruyenchufull.online/dam-my", script: "gen.js" },
    ]);
}